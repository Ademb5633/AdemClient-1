package com.ademclient.mixin;

import com.ademclient.module.impl.XRay;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Collections;
import java.util.List;

@Mixin(BakedModel.class)
public interface MixinBlockModel {

    @Inject(method = "getQuads", at = @At("RETURN"), cancellable = true)
    default void onGetQuads(BlockState state, Direction face, Random random,
                            CallbackInfoReturnable<List<BakedQuad>> cir) {
        if (XRay.INSTANCE == null || !XRay.INSTANCE.isEnabled()) return;
        if (state == null) return;
        if (!XRay.VISIBLE_BLOCKS.contains(state.getBlock())) {
            cir.setReturnValue(Collections.emptyList());
        }
    }
}
