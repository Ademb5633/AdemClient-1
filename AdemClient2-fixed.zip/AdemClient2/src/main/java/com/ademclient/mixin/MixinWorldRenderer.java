package com.ademclient.mixin;

import com.ademclient.module.impl.ChestESP;
import com.ademclient.module.impl.PlayerESP;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class MixinWorldRenderer {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderTail(MatrixStack matrices, float tickDelta, long limitTime,
                               boolean renderBlockOutline, Camera camera,
                               GameRenderer gameRenderer,
                               LightmapTextureManager lightmapTextureManager,
                               Matrix4f matrix4f, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ChestESP.INSTANCE != null) ChestESP.INSTANCE.renderChests(mc, matrices, camera);
        if (PlayerESP.INSTANCE != null) PlayerESP.INSTANCE.renderPlayers(mc, matrices, camera);
    }
}
