package com.ademclient.module;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public abstract class Module {
    private final String name;
    private boolean enabled = false;
    private final int keybind;

    public Module(String name, int keybind) {
        this.name = name;
        this.keybind = keybind;
    }

    public void onTick(MinecraftClient client) {}
    public void onEnable() {}
    public void onDisable() {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public boolean isEnabled() { return enabled; }
    public String getName() { return name; }
    public int getKeybind() { return keybind; }
}
