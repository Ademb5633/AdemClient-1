package com.ademclient.module.impl;

import com.ademclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

public class PlayerESP extends Module {
    public static PlayerESP INSTANCE;

    public PlayerESP() {
        super("PlayerESP", GLFW.GLFW_KEY_P);
        INSTANCE = this;
    }

    public void renderPlayers(MinecraftClient client, MatrixStack matrices, Camera camera) {
        if (!isEnabled() || client.world == null || client.player == null) return;

        double cx = camera.getPos().x;
        double cy = camera.getPos().y;
        double cz = camera.getPos().z;

        for (PlayerEntity player : client.world.getPlayers()) {
            if (player == client.player) continue;
            Box box = player.getBoundingBox();
            RenderUtil.drawOutlinedBox(
                matrices,
                new Box(box.minX-cx, box.minY-cy, box.minZ-cz,
                        box.maxX-cx, box.maxY-cy, box.maxZ-cz),
                0f, 1f, 0f, 1f
            );
        }
    }
}
