package com.ademclient.module;

import com.ademclient.module.impl.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final boolean[] keyState = new boolean[GLFW.GLFW_KEY_LAST];

    public void init() {
        modules.add(new ItemDuplicator());
        modules.add(new EnchantAdder());
        modules.add(new ChestESP());
        modules.add(new PlayerESP());
        modules.add(new XRay());
        modules.add(new Flight());
    }

    public void onTick(MinecraftClient client) {
        if (client.player == null) return;

        for (Module m : modules) {
            int key = m.getKeybind();
            if (key < 0 || key >= keyState.length) continue;

            boolean pressed = GLFW.glfwGetKey(client.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
            if (pressed && !keyState[key]) {
                m.toggle();
                client.player.sendMessage(
                    net.minecraft.text.Text.literal(
                        "[AdemClient] " + m.getName() + " " + (m.isEnabled() ? "§aON" : "§cOFF")
                    ),
                    true
                );
            }
            keyState[key] = pressed;

            if (m.isEnabled()) m.onTick(client);
        }
    }

    public List<Module> getModules() { return modules; }
}
