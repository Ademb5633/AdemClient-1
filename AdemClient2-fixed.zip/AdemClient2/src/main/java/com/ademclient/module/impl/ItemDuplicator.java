package com.ademclient.module.impl;

import com.ademclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class ItemDuplicator extends Module {
    private int cooldown = 0;

    public ItemDuplicator() {
        super("ItemDuplicator", GLFW.GLFW_KEY_R);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) return;
        if (cooldown-- > 0) return;

        ItemStack held = client.player.getMainHandStack();
        if (held.isEmpty()) return;

        if (client.player.getAbilities().creativeMode) {
            ItemStack copy = held.copy();
            copy.setCount(copy.getMaxCount());
            client.player.networkHandler.sendPacket(
                new CreativeInventoryActionC2SPacket(
                    36 + client.player.getInventory().selectedSlot, copy)
            );
            cooldown = 20;
        } else {
            client.interactionManager.clickSlot(
                client.player.currentScreenHandler.syncId,
                36 + client.player.getInventory().selectedSlot,
                0,
                SlotActionType.CLONE,
                client.player
            );
            cooldown = 10;
        }
        toggle();
    }
}
