package com.ademclient.module.impl;

import com.ademclient.module.Module;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.Set;

public class XRay extends Module {
    public static XRay INSTANCE;

    public static final Set<Block> VISIBLE_BLOCKS = Set.of(
        Blocks.DIAMOND_ORE,         Blocks.DEEPSLATE_DIAMOND_ORE,
        Blocks.EMERALD_ORE,         Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.GOLD_ORE,            Blocks.DEEPSLATE_GOLD_ORE,
        Blocks.IRON_ORE,            Blocks.DEEPSLATE_IRON_ORE,
        Blocks.COAL_ORE,            Blocks.DEEPSLATE_COAL_ORE,
        Blocks.LAPIS_ORE,           Blocks.DEEPSLATE_LAPIS_ORE,
        Blocks.REDSTONE_ORE,        Blocks.DEEPSLATE_REDSTONE_ORE,
        Blocks.COPPER_ORE,          Blocks.DEEPSLATE_COPPER_ORE,
        Blocks.NETHER_GOLD_ORE,     Blocks.NETHER_QUARTZ_ORE,
        Blocks.ANCIENT_DEBRIS,
        Blocks.CHEST,               Blocks.TRAPPED_CHEST,
        Blocks.ENDER_CHEST,         Blocks.BARREL,
        Blocks.SHULKER_BOX,         Blocks.SPAWNER,
        Blocks.AIR,                 Blocks.CAVE_AIR,
        Blocks.VOID_AIR,            Blocks.WATER,
        Blocks.LAVA
    );

    public XRay() {
        super("XRay", GLFW.GLFW_KEY_Z);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }
}
