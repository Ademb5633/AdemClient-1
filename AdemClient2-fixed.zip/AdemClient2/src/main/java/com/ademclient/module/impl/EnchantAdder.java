package com.ademclient.module.impl;

import com.ademclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class EnchantAdder extends Module {

    public EnchantAdder() {
        super("EnchantAdder", GLFW.GLFW_KEY_G);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;

        if (!client.player.getAbilities().creativeMode) {
            client.player.sendMessage(
                net.minecraft.text.Text.literal("§c[AdemClient] EnchantAdder requires Creative mode."),
                true
            );
            toggle();
            return;
        }

        ItemStack held = client.player.getMainHandStack();
        if (held.isEmpty()) { toggle(); return; }

        Map<Enchantment, Integer> enchants = new HashMap<>();
        for (Enchantment ench : Registries.ENCHANTMENT) {
            enchants.put(ench, ench.getMaxLevel());
        }
        EnchantmentHelper.set(enchants, held);

        client.player.networkHandler.sendPacket(
            new CreativeInventoryActionC2SPacket(
                36 + client.player.getInventory().selectedSlot, held)
        );
        toggle();
    }
}
